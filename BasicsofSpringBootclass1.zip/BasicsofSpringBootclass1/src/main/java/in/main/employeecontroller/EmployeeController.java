package in.main.employeecontroller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/apis")
public class EmployeeController {
	@GetMapping("/get")
	public String getMessage() {
		return "Your request has been processed well...";
		
	}
	
    
	@PostMapping("/post")
	public String postMessage(@RequestBody String name) {
		return " User Name is :"+name;
		
	}
}
